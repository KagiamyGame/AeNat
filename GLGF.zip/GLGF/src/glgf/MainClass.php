<?php

namespace glgf;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerRespawnEvent;
use pocketmine\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\Server;
use pocketmine\utils\TextFormat;

class MainClass extends PluginBase implements Listener{

	public function onLoad(){
		$this->getLogger()->info(TextFormat::WHITE . "[GLGF] Loaded!");
	}

	public function onEnable(){
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		$this->getLogger()->info(TextFormat::GREEN . "[GLGF] have been Enabled!");
    }

	public function onDisable(){
		$this->getLogger()->info(TextFormat::RED . "[GLGF] have been Disabled!");
	}

	public function onCommand(CommandSender $sender, Command $command, $label, array $args){
		switch($command->getName()){
			case "dnt":
				$sender->sendMessage(TextFormat::AQUA . "§7>§bTruy cập vào link §fhttp://bit.ly/glgfdnt §bGặp §eThành §bđể được hướng đẫn nạp §eVip");
				$sender->sendMessage(TextFormat::AQUA . "§7>§bTruy cập vào link §fhttp://bit.ly/glgf-dnt §bĐể donate (nạp vip)");
				$sender->sendMessage(TextFormat::AQUA . "§7>§aNạp vip sẽ được hưởng các quyền lợi lớn.");
				$sender->sendMessage(TextFormat::AQUA . "§7>§bDùng lệnh §a/Vip §bđể xem từng mức độ §6Vip");
				return true;
			case "vip":
					$sender->sendMessage(TextFormat::AQUA . "§7>§bDùng lệnh §a/dnt §bđể được xem hướng dẫn nạp §6Vip§0");
					$sender->sendMessage(TextFormat::BLUE . "20k/VIP 7 Ngày ,Tên Màu Rank Mới Được 2000 Coins");
					$sender->sendMessage(TextFormat::BLUE . "50k/VIP 1 Tháng ,Tên Màu Rank Mới Pet Và 5000 Coins");
					$sender->sendMessage(TextFormat::BLUE . "150k/VIP 6 Tháng ,Tên Màu Rank Mới Pet Nhảy Cao Và 15000 Coins");
					$sender->sendMessage(TextFormat::BLUE . "500k/VIP 1 Năm ,Tên Màu Rank Mới Pet Fly Nhảy Cao Và 50000 Coins");
					$sender->sendMessage(TextFormat::BLUE . "700k/VIP 1 Năm Rưỡi ,Tên Màu Rank Mới Pet Chạy Nhanh Fly 70000 Coins");
					$sender->sendMessage(TextFormat::BLUE . "1000k/VIP 2 Năm ,Tên Màu Rank Mới Pet Chạy Nhanh 2 Fly 100000 Coins Free Diamond Katana");
					$sender->sendMessage(TextFormat::BLUE . "1500k/VIP 2 Năm Rưỡi ,Tên Màu Rank Mới Pet Chạy Nhanh Nhảy Cao 150000 Coins Free Diamond Katana");
					$sender->sendMessage(TextFormat::BLUE . "2000k/VIP 3 Năm ,Tên Màu Rank Mới Pet Chạy Nhanh 3 Nhảy Cao 2 200000 Coins Free Diamond Katana");
					$sender->sendMessage(TextFormat::BLUE . "§7>§aTrong thời hạn còn §aVip có thể nạp thêm để nâng §eVip§0");
					$sender->sendMessage(TextFormat::BLUE . "§7>§aCòn nhiều ưu đãi ẩn dành cho các §eVip,đóng góp và có ích cho §dServer§0");
					return true;
			case "howgame":
					$sender->sendMessage(TextFormat::GREEN . "§bDùng Lệnh §a/go §bđể xem tất cả go có trong server");
					$sender->sendMessage(TextFormat::GREEN . "§bDùng Lệnh §a/go Parkour §bđể đến khu §aParkour");
					$sender->sendMessage(TextFormat::GREEN . "§bDùng Lệnh §a/go spawn §bĐể đến khu §cSpawn");
					return true;
			case "rules":
					$sender->sendMessage(TextFormat::BLUE . "                 §l§c>>§aGL§cGF§c<<");
					$sender->sendMessage(TextFormat::GREEN . "§7>§f1:§bKhông Spam, Chửi tục, thề, không xin staff và không quảng cáo server khác");
					$sender->sendMessage(TextFormat::GREEN . "§7>§f2:§bKhông chửi hoặc xúc phạm đến staff của server");
					$sender->sendMessage(TextFormat::GREEN . "§7>§f3:§bKhông nên sử dụng các phần mềm hack, bug, cheat. Nếu sử dụng mà bị bắt được sẽ sử phạt nặng");
					$sender->sendMessage(TextFormat::GREEN . "§7>§f4:§bHãy chơi game hoà đồng với mọi người trong server");
					$sender->sendMessage(TextFormat::GOLD . "§7>§bHãy thực hiện đúng những điều trên để có một server tốt đẹp, vững vàng");
					return true;
			case "glgf":
					$sender->sendMessage(TextFormat::GREEN . "Server §cGLGF §ePlay");
					$sender->sendMessage(TextFormat::GREEN . "§7>§eĐược tạo bởi KagiamyWasen");
					$sender->sendMessage(TextFormat::GREEN . "§7>§eDùng Lệnh §6/vip, /howgame, /dnt, /rules");
					$sender->sendMessage(TextFormat::GREEN . "Phiên Bản: 4.0.0");
					$sender->sendMessage(TextFormat::GOLD . "Người tạo: Kagiamy");
					$sender->sendMessage(TextFormat::GOLD . "Sửa Chữa: Kagiamy");
					return true;
			default:
				return false;
		}
	}
}
