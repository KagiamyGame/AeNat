=== iBuddy ===
Theme Name: iBuddy
Author: Ayman Al Zarrad
Author URI: http://profiles.wordpress.org/aymanalzarrad/
Description: Fast and Beautiful BuddyPress Theme
Version: 1.0.2
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Tags: buddypress, flexible-width, two-columns, right-sidebar, custom-colors, custom-menu, featured-image-header, featured-images, sticky-post, theme-options, translation-ready, blue, red, pink, orange, green
Text Domain: ibuddy
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=L46CFL4B4UWSJ&lc=US&item_name=Ayman%20Al%20Zarrad&no_note=0&cn=Add%20special%20instructions%20to%20seller%3a&no_shipping=2&currency_code=USD&bn=PP%2dDonationsBF%3abtn_donateCC_LG%2egif%3aNonHosted

== credits and licenses ==
All the resources used to build this theme are licensed under GNU General Public License:
iBuddy is based on Underscores http://underscores.me/, (C) 2012-2013 Automattic, Inc.
iBuddy option panel is based on Options Framework Theme http://wptheming.com/options-framework-theme/.


== Changelog ==
= v1.0.2 =
- Call to undefined function bp_has_groups() on Home page tamplate. Fixed
- Warning: Cannot modify header information - headers already sent (custom-sidebars.php:84). Fixed

= v1.0.1 =
- Minor bugs fixes

= v1.0 =
- Initial release


