<?php
/**
 * iBuddy custom functions and definitions
 *
 * @package iBuddy
 */

/** HERE YOU CAN ADD YOUR CUSTOM FUNCTIONS */



/*******************************************/
?>
