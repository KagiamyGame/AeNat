<?php
namespace TheDeibo;

use pocketmine\utils\TextFormat;
use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\command\CommandSender;
use pocketmine\command\Command;
use pocketmine\Player;

class Main extends PluginBase implements Listener{
	public function onEnable(){
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		$this->saveDefaultConfig();
		$this->getLogger()->info(TEXTFORMAT::GOLD . "[Donate]" .TEXTFORMAT::RED. " --> -->" .TEXTFORMAT::AQUA.  " Đây Là Plugins Donate Của AeNat Api 2.0.9!");
	}
	public function onCommand(CommandSender $sender, Command $command, $label, array $args) {
        $cmd = strtolower($command->getName());
        switch ($cmd){
            case "Donate":
                if (!($sender instanceof Player)){
                    $sender->sendMessage(TEXTFORMAT::GOLD . "--------[Donate Server]--------");
                    $sender->sendMessage(TEXTFORMAT::GREEN . "- " . $this->getConfig()->get("napthe1"));
                    $sender->sendMessage(TEXTFORMAT::GREEN . "- " . $this->getConfig()->get("napthe2"));
                    $sender->sendMessage(TEXTFORMAT::GREEN . "- " . $this->getConfig()->get("napthe3"));
                    $sender->sendMessage(TEXTFORMAT::GREEN . "- " . $this->getConfig()->get("napthe4"));
                    $sender->sendMessage(TEXTFORMAT::GREEN . "- " . $this->getConfig()->get("napthe5"));
                    return true;
                }
                $player = $this->getServer()->getPlayer($sender->getName());
                if ($player->hasPermission("marinostudios.staff")){
                    $sender->sendMessage("§c--------§e[§aDonate §bServer]§c--------");
                    $sender->sendMessage("§b- " . $this->getConfig()->get("napthe1"));
                    $sender->sendMessage("§a- " . $this->getConfig()->get("napthe2"));
                    $sender->sendMessage("§b- " . $this->getConfig()->get("napthe3"));
                    $sender->sendMessage("§a- " . $this->getConfig()->get("napthe4"));
                    $sender->sendMessage("§b- " . $this->getConfig()->get("napthe5"));
                    return true;
                }
                break;
            }
        }
    }
?>