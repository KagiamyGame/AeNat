<?php
namespace GLGFSocial;
use pocketmine\utils\TextFormat;
use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\command\CommandSender;
use pocketmine\command\Command;
use pocketmine\Player;

use GLGFSocial\config\website;
use GLGFSocial\config\votesocial;
use GLGFSocial\config\facebook;

class Main extends PluginBase implements Listener{
	public function onEnable(){
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		$this->saveDefaultConfig();
		$this->getLogger()->info(TEXTFORMAT::GOLD . "[GLGFSocial]" .TEXTFORMAT::RED. " --> -->" .TEXTFORMAT::AQUA.  " Social Success! GLGFSocial is Active on Version ".$this->getDescription()->getVersion());
    }
    	public function onCommand(CommandSender $sender, Command $command, $label, array $args) {
        $cmd = strtolower($command->getName());
        switch ($cmd){
            case "social":
                if (!($sender instanceof Player)){
                    $sender->sendMessage(TEXTFORMAT::BLUE . "- " . $this->getConfig()->get("name"));
                    $sender->sendMessage(TEXTFORMAT::GOLD . "-  Our Website!");
                    $sender->sendMessage(TEXTFORMAT::GREEN . "-  Use /website");
                    $sender->sendMessage(TEXTFORMAT::GOLD . "-  Our Facebook!");
                    $sender->sendMessage(TEXTFORMAT::GREEN . "-  Use /facebook");
                    $sender->sendMessage(TEXTFORMAT::GOLD . "-  Our Vote!");
                    $sender->sendMessage(TEXTFORMAT::GREEN . "-  Use /votesocial");
                    return true;
                }
                $player = $this->getServer()->getPlayer($sender->getName());
                if ($player->hasPermission("glgfs.glgfs")){
                    $sender->sendMessage("§3 " . $this->getConfig->get("name"));
                    $sender->sendMessage("§2-  Our Website!");
                    $sender->sendMessage("§a-  Use /website");
                    $sender->sendMessage("§2-  Our Facebook!");
                    $sender->sendMessage("§a-  Use /facebook");
                    $sender->sendMessage("§2-  Our Vote!");
                    $sender->sendMessage("§a-  Use /votesocial"); 
                    return true;
                }
                break;
            }
        }
    }
?>
