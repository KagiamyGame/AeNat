# PunchSound
Inspired by a minigame from Hypixel. Plays a sound on EntityDamageByEntityEvent
