<?php

class Card {
	protected  $stage;
	protected $seri;
	protected  $pin;
	protected  $mang;
	public function  __init(){
		$this->stage = 0;
	}
}